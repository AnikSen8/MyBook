MYBOOK REAL BACKEND STARTER
============================
এই প্যাকেজে frontend + Node/Express backend + Supabase schema আছে।

সেটআপ:
1. Supabase-এ একটি project তৈরি করুন।
2. SQL Editor-এ supabase_schema.sql চালান।
3. books table-এ নিজের বৈধ বই, দাম ও stock যোগ করুন।
4. backend folder-এ .env তৈরি করে SUPABASE_URL এবং SUPABASE_SERVICE_ROLE_KEY দিন।
5. npm install && npm start
6. frontend/index.html-এর API_URL-এ backend URL বসান।

নিরাপত্তা:
- service_role key কখনো frontend-এ রাখবেন না।
- Admin login/RLS production-এ অবশ্যই configure করতে হবে।
- বাস্তব customer data ব্যবহার করার আগে privacy notice, access controls এবং secure hosting সেট করুন।

নোট:
আমি তোমার হয়ে Supabase account/domain/hosting account তৈরি বা credentials ব্যবহার করতে পারি না। এগুলো তোমার account-এ করতে হবে।
