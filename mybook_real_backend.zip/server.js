// MyBook backend — Node.js + Express + Supabase
// Install: npm install
// Run: npm start
const express=require("express"), cors=require("cors");
const {createClient}=require("@supabase/supabase-js");
require("dotenv").config();
const app=express(); app.use(cors()); app.use(express.json());
const supabase=createClient(process.env.SUPABASE_URL,process.env.SUPABASE_SERVICE_ROLE_KEY);

app.get("/books",async(req,res)=>{
 const {data,error}=await supabase.from("books").select("id,title,author,price,stock").eq("active",true).gt("stock",0).order("id");
 if(error)return res.status(500).json({error:error.message}); res.json(data);
});
app.post("/orders",async(req,res)=>{
 const {customer_name,phone,address,items}=req.body||{};
 if(!customer_name||!phone||!address||!Array.isArray(items)||!items.length)return res.status(400).json({error:"Invalid order"});
 // Keep this endpoint limited to the declared Bongaon service area.
 const text=(address+"").toLowerCase();
 const allowed=["bongaon","বনগাঁ","banagaon","bonagaon"];
 if(!allowed.some(x=>text.includes(x)))return res.status(400).json({error:"শুধু বনগাঁ এলাকার অর্ডার গ্রহণ করা হয়"});
 const ids=items.map(x=>x.book_id);
 const {data:books,error:be}=await supabase.from("books").select("id,title,price,stock").in("id",ids).eq("active",true);
 if(be)return res.status(500).json({error:be.message});
 let total=0,lines=[];
 for(const item of items){const b=books.find(x=>x.id===item.book_id),q=Number(item.quantity);
   if(!b||!Number.isInteger(q)||q<1||q>b.stock)return res.status(400).json({error:"বই/স্টক সঠিক নয়"});
   total+=Number(b.price)*q;lines.push({book_id:b.id,title:b.title,quantity:q,unit_price:b.price});
 }
 const code="MB-"+Date.now().toString().slice(-8);
 const {data:o,error:oe}=await supabase.from("orders").insert({order_code:code,customer_name,phone,address,area:"Bongaon",status:"placed",total}).select("id,order_code").single();
 if(oe)return res.status(500).json({error:oe.message});
 const rows=lines.map(x=>({...x,order_id:o.id}));
 const {error:ie}=await supabase.from("order_items").insert(rows);
 if(ie)return res.status(500).json({error:ie.message});
 res.status(201).json(o);
});
app.get("/health",(req,res)=>res.json({ok:true}));
app.listen(process.env.PORT||3000,()=>console.log("MyBook backend running"));
